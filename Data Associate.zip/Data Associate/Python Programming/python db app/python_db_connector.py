# -*- coding: utf-8 -*-
"""
        connection
py app -->sqlite
results -->table
"""

import sqlite3

print("this is py db")

con=sqlite3.connect("employ_db")

cursorObj = con.cursor()
cursorObj.execute(
    "create table employ(id integer primary key, name text , salary real, department text, position text, hiredate text)"
    )
con.commit()

cursorObj.execute("insert into employ values(1,'Apurva',10000,'IT','Developer','2021-03-01')")
con.commit()

cursorObj.execute("insert into employ values(3,'Bhavesh',15000,'IT','Developer','2021-03-01')")
con.commit()

entities=(4,'Dayanand',220000,'BI','Project manager','2019-04-06')
cursorObj.execute("insert into employ values(?,?,?,?,?,?)",entities)
con.commit()

cursorObj.execute("select * from employ")
rows =cursorObj.fetchall()
for row in rows:
    print(row)
    
cursorObj.execute("select * from employ where department='IT'")
rows =cursorObj.fetchall()
for row in rows:
    print(row)


cursorObj.execute("update employ set department ='BI' where id=4")
con.commit()

#inserting multiple rows

cursorObj.execute('create table projects(id integer, name text)')

data =[(1,"RideSharing"),(2,"Purifying"),(3,"Forensics"),(4,"Botany")]
   
cursorObj.executemany("INSERT INTO projects VALUES(?,?)",data)
con.commit() 


# delete a row
# drop table

con.close













  