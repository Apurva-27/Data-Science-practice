# -*- coding: utf-8 -*-

import mysql.connector

db_connection=mysql.connector.connect(
    host="localhost",#host="127.0.0.1",
    user="root",
    password="root"
    )

db_cursor=db_connection.cursor(buffered=True)
db_cursor.execute("show databases")
for db in db_cursor:
    print(db)

#craete tables - MOVIES , REVIEWERS, RATINGS
query_create_db="create database online_movies"
db_cursor.execute(query_create_db)

db_cursor.execute("use online_movies")

create_movies_table_query = """
CREATE TABLE movies(
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100),
    release_year YEAR(4),
    genre VARCHAR(100),
    collection_in_mil INT
)
"""
db_cursor.execute(create_movies_table_query)


create_reviewers_table_query = """
CREATE TABLE reviewers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(100),
    last_name VARCHAR(100)
)
"""
db_cursor.execute(create_reviewers_table_query) 

create_ratings_table_query = """
CREATE TABLE ratings (
    movie_id INT,
    reviewer_id INT,
    rating DECIMAL(2,1),
    FOREIGN KEY(movie_id) REFERENCES movies(id),
    FOREIGN KEY(reviewer_id) REFERENCES reviewers(id),
    PRIMARY KEY(movie_id, reviewer_id)
)
"""
db_cursor.execute(create_ratings_table_query)

show_table_query="describe movies"
db_cursor.execute("describe movies")
result=db_cursor.fetchall()
for column in result:
    print(column)

insert_movies_query = """
INSERT INTO movies (title, release_year, genre, collection_in_mil)
VALUES
    ("Forrest Gump", 1994, "Drama", 330.2),
    ("3 Idiots", 2009, "Drama", 2.4),
    ("Eternal Sunshine of the Spotless Mind", 2004, "Drama", 34.5),
    ("Good Will Hunting", 1997, "Drama", 138.1),
    ("Skyfall", 2012, "Action", 304.6),
    ("Gladiator", 2000, "Action", 188.7),
    ("Black", 2005, "Drama", 3.0),
    ("Titanic", 1997, "Romance", 659.2),
    ("The Shawshank Redemption", 1994, "Drama",28.4),
    ("Udaan", 2010, "Drama", 1.5),
    ("Home Alone", 1990, "Comedy", 286.9),
    ("Casablanca", 1942, "Romance", 1.0),
    ("Avengers: Endgame", 2019, "Action", 858.8),
    ("Night of the Living Dead", 1968, "Horror", 2.5),
    ("The Godfather", 1972, "Crime", 135.6),
    ("Haider", 2014, "Action", 4.2),
    ("Inception", 2010, "Adventure", 293.7),
    ("Evil", 2003, "Horror", 1.3),
    ("Toy Story 4", 2019, "Animation", 434.9),
    ("Air Force One", 1997, "Drama", 138.1),
    ("The Dark Knight", 2008, "Action",535.4),
    ("Bhaag Milkha Bhaag", 2013, "Sport", 4.1),
    ("The Lion King", 1994, "Animation", 423.6),
    ("Pulp Fiction", 1994, "Crime", 108.8),
    ("Kai Po Che", 2013, "Sport", 6.0),
    ("Beasts of No Nation", 2015, "War", 1.4),
    ("Andadhun", 2018, "Thriller", 2.9),
    ("The Silence of the Lambs", 1991, "Crime", 68.2),
    ("Deadpool", 2016, "Action", 363.6),
    ("Drishyam", 2015, "Mystery", 3.0)
"""


db_cursor.execute(insert_movies_query)
db_connection.commit()

#insserting veiwers' data


insert_reviewers_query = """
INSERT INTO reviewers
(first_name, last_name)
VALUES ( %s, %s )
"""
reviewers_records=[
    ("garima","chandrakar"),
    ("kajal","agunde"),
    ("keshav","patil"),
    ("mayuri","yadav"),
    ("shubham","k")
    ]
db_cursor.executemany(insert_reviewers_query,reviewers_records)
db_connection.commit()

insert_ratings_query = """
INSERT INTO ratings
(rating, movie_id, reviewer_id)
VALUES ( %s, %s, %s)
"""
ratings_records = [
    (6.4, 3, 5), (5.6, 19, 1), (6.3, 22, 2), (5.1, 21, 3),
    (5.0, 5, 5), (6.5, 21, 5), (8.5, 30, 3), (9.7, 6, 1),
    (8.5, 24, 1), (9.9, 14, 2), (8.7, 26, 2), (9.9, 6, 4)
]

db_cursor.executemany(insert_ratings_query,ratings_records)
db_connection.commit()

"""
IntegrityError: Cannot add or update a child row: 
a foreign key constraint fails (`online_movies`.`ratings`, 
CONSTRAINT `ratings_ibfk_1` FOREIGN KEY (`movie_id`) 
REFERENCES `movies` (`id`))
"""
db_connection.close()


